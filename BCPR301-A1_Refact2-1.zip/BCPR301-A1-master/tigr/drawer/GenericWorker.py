import time
import tkinter as tk


class GenericWorker:

    def __init__(self):
        self.window = tk.Tk()
        self.canvas = tk.Canvas(self.window, width=800, height=600)

    def bye(self):
        time.sleep(0.5)