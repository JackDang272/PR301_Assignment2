# Why it is portable    

- It runs well on Windows OS
- It runs well on macOS
- It runs well on Linux
