import re

from tigr.tigr_interface import AbstractParser


class RegexParser(AbstractParser):
    pattern = r'^([DUPNESWXYGL])\s*(-?[\s\d]+)?(?:#.*)?$'
    p = re.compile(pattern, re.IGNORECASE)

    def __init__(self, drawer):
        super().__init__(drawer)
        self.draw_methods = {
            'D': self.drawer.pen_down,
            'U': self.drawer.pen_up,
            'G': self.drawer.goto,
            'N': self.drawer.draw_line,
            'S': self.drawer.draw_line,
            'W': self.drawer.draw_line,
            'E': self.drawer.draw_line,
            'P': self.drawer.select_pen,
            'X': self.drawer.go_along,
            'Y': self.drawer.go_down,
            'L': self.drawer.draw_line,
        }
        self.draw_degrees = {
            'N': 90,
            'S': 270,
            'E': 0,
            'W': 180,
        }

    def parseline(self, line):
        line = line.strip()
        match = self.p.match(line)
        result = {
            'error_message': '',
            'command': {
                'line': line,
                'operand': []
            }
        }
        if match:
            cmd, data = match.groups()
            cmd = cmd.upper()
            result['command']['cmd'] = cmd
            result['command']['data'] = data
            result = self._check_data(result)
            if result['command']['data'] is not None:
                print(result)
                result = self._check_operand(result)
        else:
            if line[0] == '#':
                result['error_message'] = f'skip comment line: {line}'
            else:
                result['error_message'] = f'invalid command: ' \
                                          f'"{line}". unrecognized command.'
        return result

    def _check_data(self, result):
        data = result['command']['data']
        cmd = result['command']['cmd']
        line = result['command']['line']

        if data is not None and (cmd == 'U' or cmd == 'D'):
            result['error_message'] = f'invalid command: "{line}". {cmd} ' \
                                      f'need not any number but got number(s)'
        if data is None:
            if cmd != 'U' and cmd != 'D':
                result['error_message'] = f'invalid command: "{line}". ' \
                                          f'{cmd} need number(s) but get none'
        return result

    def _check_operand(self, result):
        data = result['command']['data']
        cmd = result['command']['cmd']
        line = result['command']['line']

        print(re.split(r'\s+', data.strip()))
        operand = [int(i) for i in re.split(r'\s+', data.strip())]
        count = len(operand)
        result['command']['operand'] = operand
        if cmd == 'G' or cmd == 'L':
            if count != 2:
                result['error_message'] = f'invalid command: "{line}". ' \
                                          f'{cmd} need 2 numbers but ' \
                                          f'get {count} number(s)'
                result['command'] = None
        else:
            if count != 1:
                result['error_message'] = f'invalid command: "{line}". ' \
                                          f'{cmd} need 1 number but ' \
                                          f'get {count} number(s)'
                result['command'] = None
        return result

    def parse(self, file):
        self.drawer.reset()
        for line in file:
            line = line.strip()
            if line != '':
                cmd = self.parseline(line)
                if cmd['error_message']:
                    print(cmd['error_message'])
                else:
                    self.do(cmd['command'])

    def do(self, command):
        if command['cmd'] in self.draw_degrees:
            command['operand'].insert(0, self.draw_degrees[command['cmd']])
        self.draw_methods[command['cmd']](*command['operand'])

# if __name__ == '__main__':
#
#     from tigr.drawer.drawer import Drawer
#     if 1:
#         from tigr.drawer.turtle_worker import TurtleWorker as Worker
#     else:
#         from tigr.drawer.tkinter_worker import TkinterWorker as Worker
#
#     drawer = Drawer(Worker())
#     parser = RegexParser(drawer)
#     parser.parse(open('../test/instructions2.txt'))
#
#     import time
#
#     time.sleep(0.5)
#
#     from tigr.shell.shell import Shell
#
#     Shell(drawer).cmdloop()
