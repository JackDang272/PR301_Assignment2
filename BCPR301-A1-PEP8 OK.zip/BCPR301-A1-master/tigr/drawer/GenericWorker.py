from abc import abstractmethod

from tigr.tigr_interface import AbstractDrawer
import time
import tkinter as tk


class GenericWorker(AbstractDrawer):
    pen_list = [
        {
            'pencolor': 'black',
            'pensize': 1
        },
        {
            'pencolor': 'black',
            'pensize': 2
        },
        {
            'pencolor': 'black',
            'pensize': 3
        },
        {
            'pencolor': 'red',
            'pensize': 1
        },
        {
            'pencolor': 'red',
            'pensize': 2
        },
        {
            'pencolor': 'red',
            'pensize': 3
        },
        {
            'pencolor': 'blue',
            'pensize': 1
        },
        {
            'pencolor': 'blue',
            'pensize': 2
        },
        {
            'pencolor': 'blue',
            'pensize': 3
        },
    ]

    def __init__(self):
        self.window = tk.Tk()
        self.canvas = tk.Canvas(self.window, width=800, height=600)

    def bye(self):
        time.sleep(0.5)

    @abstractmethod
    def select_pen(self, pen_num):
        pass

    @abstractmethod
    def pen_down(self):
        pass

    @abstractmethod
    def pen_up(self):
        pass

    @abstractmethod
    def go_along(self, along):
        pass

    @abstractmethod
    def go_down(self, down):
        pass

    @abstractmethod
    def draw_line(self, direction, distance):
        pass
