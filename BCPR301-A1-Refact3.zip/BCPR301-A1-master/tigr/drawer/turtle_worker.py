import turtle
from tigr.drawer.GenericWorker import GenericWorker
import logging, sys
logging.basicConfig(stream=sys.stderr, level=logging.CRITICAL)
debug = logging.debug


class TurtleWorker(GenericWorker):
    name = 'turtle'

    def __init__(self, speed=6, pen_color='black', pen_size=2):
        super().__init__()
        self.window.title('Turtle drawer')
        self.canvas.pack()
        self.cursor = turtle.RawPen(self.canvas)
        self.cursor.pencolor(pen_color)
        self.speed(speed)
        self.cursor.pensize(int(pen_size))
        self.goto(400, 300)

    def select_pen(self, pen):
        """pen should be a integer from 1 to 9, every pen has a pencolor and pensize attribute
        """
        pen = int(pen)
        if pen < 1 or pen > 9:
            debug(f'invalid pen: {pen}, should be a integer between 1 and 9')
            return False
        self.pen_size(self.pen_list[pen - 1]['pensize'])
        self.pen_color(self.pen_list[pen - 1]['pencolor'])

    def go_down(self, length):
        if length > 0:
            heading = 270
        else:
            heading = 90
        self.cursor.setheading(heading)
        self.cursor.forward(abs(length))

    def go_along(self, along):
        if along > 0:
            heading = 0
        else:
            heading = 180
        self.cursor.setheading(heading)
        self.cursor.forward(abs(along))

    def draw_line(self, direction, distance):
        self.cursor.pendown()
        self.cursor.setheading(direction)
        self.cursor.forward(distance)

    def goto(self, x, y):
        x -= 400
        if y > 300:
            y -= 2 * y - 300
        else:
            y = 300 - y

        if self.cursor.pen()['pendown']:
            self.cursor.penup()
            self.cursor.goto(x, y)
            self.cursor.pendown()
        else:
            self.cursor.goto(x, y)

    def speed(self, speed):
        speed = int(speed)
        if speed > 10:
            speed = 0
        elif speed <= 0:
            speed = 1
        self.cursor.speed(speed)

    def pos(self):
        return tuple([int(i) for i in self.cursor.pos()])

    def pen_down(self):
        self.cursor.pendown()

    def pen_up(self):
        self.cursor.penup()

    def pen_color(self, color):
        self.cursor.pencolor(color)

    def pen_size(self, size):
        self.cursor.pensize(size)

    def forward(self, distance):
        self.cursor.forward(distance)

    def reset(self):
        self.cursor.reset()
