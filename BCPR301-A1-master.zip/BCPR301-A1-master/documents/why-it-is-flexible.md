# Why it is flexible

## It is built by several module which has loose coupling

Replace a module is not only feasible but also easy. 

## The modules can be easily replaced by other module

Drawing instructions have an uniform interface standard, so you can easily add another drawing woker.
The parser also has an uniform interface, you can easily add another parse or replace a current one.

## The functions or features can be easily extended.

Due to the well-designed architecture, you can easily add more features for this drawing system.
