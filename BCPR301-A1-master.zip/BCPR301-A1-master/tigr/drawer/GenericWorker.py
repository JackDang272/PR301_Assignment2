import time


class GenericWorker:

    def bye(self):
        time.sleep(0.5)

    # # tkinter_worker
    # def go_along(self, along):
    #     if along > 0:
    #         self._heading = 90
    #     else:
    #         self._heading = 270
    #     self.forward(abs(along))
    #
    # # turtle_worker
    # def go_along(self, along):
    #     if along > 0:
    #         heading = 0
    #     else:
    #         heading = 180
    #     self.setheading(heading)
    #     self.forward(abs(along))
    #
    # # tkinter_worker
    # def go_down(self, length):
    #     if length > 0:
    #         self._heading = 0
    #     else:
    #         self._heading = 180
    #     self.forward(abs(length))
    #     self.debug()
    # # turtle_worker
    # def go_down(self, length):
    #     if length > 0:
    #         heading = 270
    #     else:
    #         heading = 90
    #     self.setheading(heading)
    #     self.forward(abs(length))