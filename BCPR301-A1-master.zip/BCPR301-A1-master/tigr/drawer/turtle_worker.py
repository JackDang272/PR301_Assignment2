import turtle
from tkinter import Tk, Canvas
import time


class TurtleWorker:
    name = 'turtle'

    def __init__(self, speed=6, pencolor='black', pensize=2):
        # super().__init__()
        self.window = Tk()
        self.canvas = Canvas(self.window, width=800, height=600)
        self.canvas.pack()
        self.cursor = turtle.RawPen(self.canvas)
        # self.__name__ = 'turtle'
        self.cursor.pencolor(pencolor)
        self.speed(speed)
        self.cursor.pensize(int(pensize))
        self.goto(400, 300)

    def go_down(self, length):
        if length > 0:
            heading = 270
        else:
            heading = 90
        self.cursor.setheading(heading)
        self.cursor.forward(abs(length))

    def go_along(self, along):
        if along > 0:
            heading = 0
        else:
            heading = 180
        self.cursor.setheading(heading)
        self.cursor.forward(abs(along))

    def draw_line(self, direction, distance):
        self.cursor.pendown()
        self.cursor.setheading(direction)
        self.cursor.forward(distance)

    def goto(self, x, y):
        x -= 400
        if y > 300:
            y -= 2 * y - 300
        else:
            y = 300 - y

        if self.cursor.pen()['pendown']:
            self.cursor.penup()
            self.cursor.goto(x, y)
            self.cursor.pendown()
        else:
            self.cursor.goto(x, y)

    def speed(self, speed):
        speed = int(speed)
        if speed > 10:
            speed = 0
        elif speed <= 0:
            speed = 1
        self.cursor.speed(speed)

    def bye(self):
        time.sleep(0.5)

    def pos(self):
        return tuple([int(i) for i in self.cursor.pos()])

    def pendown(self):
        self.cursor.pendown()

    def penup(self):
        self.cursor.penup()

    def pencolor(self, color):
        self.cursor.pencolor(color)

    def pensize(self, size):
        self.cursor.pensize(size)

    def forward(self, distance):
        self.cursor.forward(distance)

    def reset(self):
        self.cursor.reset()
